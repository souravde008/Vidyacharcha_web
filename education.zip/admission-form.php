<?php
// $snd = false;
// if($_SERVER["REQUEST_METHOD"] == "POST"){
//     $name = $_POST["name"];
//     $phone = $_POST["phone"];
//     $topic = $_POST["topic"];
//     $msg = $_POST["message"];
//     $str = $name." have some Qustation <br> Phone No. ".$phone."<br> Topic- ".$topic." <br> Message- ".$msg;
//     $fields = array(
//         "sender_id" => "TXTIND",
//         "message" => $str,
//         "route" => "v3",
//         "numbers" => "9475409207",
//     );

//     $curl = curl_init();

//     curl_setopt_array($curl, array(
//     CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => "",
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 30,
//     CURLOPT_SSL_VERIFYHOST => 0,
//     CURLOPT_SSL_VERIFYPEER => 0,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => "POST",
//     CURLOPT_POSTFIELDS => json_encode($fields),
//     CURLOPT_HTTPHEADER => array(
//         "authorization: 6svOGiAMz3Hc0KtrwSUj2xTgWLQqCpoF8yuafDRZhb59NXnm4JVcRYnP0ZSqk7lwXivyhrQ3eUO15psd",
//         "accept: */*",
//         "cache-control: no-cache",
//         "content-type: application/json"
//     ),
//     ));

//     $response = curl_exec($curl);
//     $err = curl_error($curl);

//     curl_close($curl);

//     if ($err) {
//     echo "cURL Error #:" . $err;
//     } else {
//     $snd = true;
//     }
// }
?>




<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact</title>
    <meta name="description" content="Free Bootstrap Theme by ProBootstrap.com">
    <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
    
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,700|Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="css/styles-merged.css">
    <link rel="stylesheet" href="css/style.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <style>
    body {
        /* background: url(img/home_slide/wallpaper.jpg) repeat; */
        background: #c5f07d;
    }
    .head-line{
    height: 120px; 
    width: 220px;    
  }
  @media only screen and (max-width: 350px){
    .head-line{
        height: 120px; 
        width: 100px;
    }
    
  }
    </style>

  </head>
  <body>

    
    
    <div>
      <!-- Fixed navbar -->
      <?php require "partial/_header.php"?>
      
      <section class="probootstrap-section probootstrap-section-colored"style="margin-top:130px">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center section-heading probootstrap-animate">
              <h1 class="mb0"><b><i>Enrollment Form</b></i></h1>
            </div>
          </div>
        </div>
      </section>

      <section class="probootstrap-section probootstrap-section-sm">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              
                <div class="col-md-7 col-md-push-2  probootstrap-animate" id="probootstrap-content">
                  <h2><b><i><center>Fill This form Carefully</center></b></i></h2>
                  <ol>
                    <li style="text-align:justify;color:red;font-weight:bold">Make sure that you payment is done through online. if not <a href="admission-info.php">Click Here</a></li>
                    <li style="text-align:justify;color:red;font-weight:bold">After successful transaction you will get a transaction Id. put it into said column.</li>
                    <!-- <li>Milk</li> -->
                  </ol
                  <form action="#" method="post">
                    <div class="form-group">
                      <label for="name">Full Name*</label>
                      <input type="text" class="form-control" id="name" name="name">
                    </div>
                    <div class="form-group">
                      <label for="email">Email*</label>
                      <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="form-group">
                      <label for="email">Phone No.*</label>
                      <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="form-group">
                      <label for="email">Whatsapp No.*</label>
                      <input type="email" class="form-control" id="email" name="email">
                    </div>

                    <div class="form-group">
                      <label for="subject">Cousre*</label>
                      <input type="text" class="form-control" id="subject" name="subject">
                    </div>

                    <div class="form-group">
                      <label for="message">Full Address*</label>
                      <textarea cols="30" rows="5" class="form-control" id="message" name="message"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="subject">Teansaction ID*</label>
                      <input type="text" class="form-control" id="subject" name="subject">
                    </div>
                    <div class="form-group">
                      <label for="subject">Teansaction Date*</label>
                      <input type="text" class="form-control" id="subject" name="subject">
                    </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-success btn-lg" id="submit" name="submit" value="Submit">
                      <input type="reset" class="btn btn-danger btn-lg" id="submit" name="submit" value="Reset">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section class="probootstrap-cta">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <h2 class="probootstrap-animate" data-animate-effect="fadeInRight">Get your admission now!</h2>
              <a href="admission-info.php" role="button" class="btn btn-primary btn-lg btn-ghost probootstrap-animate" data-animate-effect="fadeInLeft">Enroll</a>
            </div>
          </div>
        </div>
      </section>


      <?php require "partial/_footer.php"?>

    </div>
    <!-- END wrapper -->
    

    <script src="js/scripts.min.js"></script>
    <script src="js/main.min.js"></script>
    <script src="js/custom.js"></script>

  </body>
</html>