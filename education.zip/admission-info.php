<?php
// $snd = false;
// if($_SERVER["REQUEST_METHOD"] == "POST"){
//     $name = $_POST["name"];
//     $phone = $_POST["phone"];
//     $topic = $_POST["topic"];
//     $msg = $_POST["message"];
//     $str = $name." have some Qustation <br> Phone No. ".$phone."<br> Topic- ".$topic." <br> Message- ".$msg;
//     $fields = array(
//         "sender_id" => "TXTIND",
//         "message" => $str,
//         "route" => "v3",
//         "numbers" => "9475409207",
//     );

//     $curl = curl_init();

//     curl_setopt_array($curl, array(
//     CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => "",
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 30,
//     CURLOPT_SSL_VERIFYHOST => 0,
//     CURLOPT_SSL_VERIFYPEER => 0,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => "POST",
//     CURLOPT_POSTFIELDS => json_encode($fields),
//     CURLOPT_HTTPHEADER => array(
//         "authorization: 6svOGiAMz3Hc0KtrwSUj2xTgWLQqCpoF8yuafDRZhb59NXnm4JVcRYnP0ZSqk7lwXivyhrQ3eUO15psd",
//         "accept: */*",
//         "cache-control: no-cache",
//         "content-type: application/json"
//     ),
//     ));

//     $response = curl_exec($curl);
//     $err = curl_error($curl);

//     curl_close($curl);

//     if ($err) {
//     echo "cURL Error #:" . $err;
//     } else {
//     $snd = true;
//     }
// }
?>




<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact</title>
    <meta name="description" content="Free Bootstrap Theme by ProBootstrap.com">
    <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
    
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,700|Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="css/styles-merged.css">
    <link rel="stylesheet" href="css/style.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Mina&display=swap" rel="stylesheet">
    <style>
.head-line{
    height: 120px; 
    width: 220px;   
  }
  @media only screen and (max-width: 350px){
    .head-line{
        height: 120px; 
        width: 100px;
    }
    
  }
  body {
        /* background: url(img/home_slide/wallpaper.jpg) repeat; */
        background: #c5f07d;
    }

    </style>

  </head>
  <body>

    
    
    <div>
      <!-- Fixed navbar -->
      <?php require "partial/_header.php"?>
      
      <section class="probootstrap-section probootstrap-section-colored"style="margin-top:130px">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center section-heading probootstrap-animate">
              <h1 class="mb0"><b><i>How to Enroll</i><b></h1>
            </div>
          </div>
        </div>
      </section>

      <section class="probootstrap-section probootstrap-section-sm">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              
                <div class="col-md-7 col-md-push-2  probootstrap-animate" id="probootstrap-content">
                  <h1 style="color:red"><b><i><center>Please Read This Carefully</center></b></i></h1>
                  <h5 style="text-align:justify;font-family: 'Mina', sans-serif; font-weight:bold;font-size:17px">ভর্তি পক্রিয়ার জন্য আপনি যে কোনো দিন সকাল ৯টা থেকে বিকাল ৫টার মধ্যে বেলুড় বিদ্যাচর্চায়  এসে ,( আসার আগে অবশ্যই  ফোন করবেন)  নিজের ২ টি পাসপোর্ট সাইজ ফটো, শেষ  পরীক্ষার রেজাল্টের প্রতিলিপি, আধার কার্ডের প্রতিলিপি এবং প্রবেশমূল্যসহ ভর্তি প্রক্রিয়া সম্পন্ন করবেন । এছাড়াও আপনি 
                    অনলাইনে (ওয়েবসাইট বা আমাদের অ্যাপ থেকে) <a href="admission-form.php">ফর্মফিলাপ</a> করে এবং ব্যাঙ্ক বা অনলাইন প্রক্রিয়ার মাধ্যমে পেমেন্ট<b style="color:red" >(Google pay, Phone Pe) </b>করেও ভর্তি হতে পারেন। পেমেন্ট সাকসেস হলে অবশ্যই ফোনে জানিয়ে দিবেন।
                  </h5>
                  <h5 style="text-align:justify;font-family: 'Mina', sans-serif;font-weight:bold;font-size:17px"> অন্য  সমস্ত প্রকার জিজ্ঞাসার জন্য বা ভর্তি হতে আসার আগে আমাদের <strong style="color:red">( 8777496117/8016158491/8348263967)</strong> সাথে যোগাযোগ করতে পারেন।
                    আমাদের প্রতিটি ব্যাচে একটি   নির্দিষ্ট সংখ্যার আসন থাকে  তাই সমস্ত আসন পূর্ণ হওয়ার পর রানিং ব্যাচের জন্য আর কোন ভর্তি নেওয়া হয় না।
                  </h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <!-- <section class="probootstrap-cta">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <h2 class="probootstrap-animate" data-animate-effect="fadeInRight">Get your admission now!</h2>
              <a href="admission-info.php" role="button" class="btn btn-primary btn-lg btn-ghost probootstrap-animate" data-animate-effect="fadeInLeft">Enroll</a>
            </div>
          </div>
        </div>
      </section> -->


      <?php require "partial/_footer.php"?>

    </div>
    <!-- END wrapper -->
    

    <script src="js/scripts.min.js"></script>
    <script src="js/main.min.js"></script>
    <script src="js/custom.js"></script>

  </body>
</html>