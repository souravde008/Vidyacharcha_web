<nav class="navbar navbar-default probootstrap-navbar navbar-fixed-top " style="background-color: #f799a6;font-weight:bold;">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- <a class="navbar-brand" href="index.php" title=""></a> -->
                <img src="img/logo/main.png" style="height: 70px; width: 80px;  " alt=""><span><img src="img/logo/sub_part.png" class="head-line" alt=""></span>
            </div>
            

            <div id="navbar-collapse" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right" style="margin-top: 19px;">
                    <li><a href="index.php" style="font-size: 20px">Home</a></li>
                    <li><a href="courses.php" style="font-size: 20px">Courses</a></li>
                    <!-- <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle" style="font-family: 'Indie Flower', cursive; font-size: 20px">Current Update</a>
                        <ul class="dropdown-menu">
                            <li><a href="events.php" style="font-family: 'Indie Flower', cursive; font-size: 20px">Events</a></li>
                            <li><a href="news.php" style="font-family: 'Indie Flower', cursive; font-size: 20px">News</a></li>
                        </ul>
                    </li> -->
                    <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle" style="font-family: 'Indie Flower', cursive; font-size: 20px">admission</a>
                        <ul class="dropdown-menu">
                            <li><a href="admission-info.php" style="font-size: 20px;">How To Enroll</a></li>
                            <li><a href="admission-form.php" style="font-size: 20px">Enrollment Form</a></li>
                        </ul>
                    </li>
                    <li><a href="study-material.php" style="font-size: 20px">Study Material</a></li>
                    <!-- <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle" style="font-family: 'Indie Flower', cursive; font-size: 20px">Subject</a>
                        <ul class="dropdown-menu">
                            <li><a href="courses.php" style="font-family: 'Indie Flower', cursive; font-size: 20px"> All Courses</a></li>
                            <li class="dropdown-submenu dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle" style="font-family: 'Indie Flower', cursive; font-size: 20px"><span>Offered Course</span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="nta-general-paper.php" style="font-family: 'Indie Flower', cursive; font-size: 20px">NTA NET General</a></li>
                                    <li><a href="nta-net-snaskrit.php" style="font-family: 'Indie Flower', cursive; font-size: 20px">NTA NET Snaskrit</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li> -->
                    <!-- <li><a href="gallery.php" style="font-family: 'Indie Flower', cursive; font-size: 20px">Gallery</a></li> -->
                    <li><a href="contact.php" style="font-size: 20px">Contact Us</a></li>
                    <li><a href="about.php" style="font-size: 20px">About Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
    